package com.cts.interim_project.Service_Providers.entities;

import com.cts.interim_project.Service_Providers.pojo.ServiceProvidersPOJO;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.Data;
import lombok.ToString;

@Data
@ToString
@Entity
@Table(name = "service_providers")
public class ServiceProviders {
	@Id
	@GeneratedValue(strategy = GenerationType.UUID)
	private String id;
	private String name;
	private String address;
	@Column(nullable = true)
	private String ownerId;
	@Column(nullable = true, length = 128)
	private String photos;
	public ServiceProviders(ServiceProvidersPOJO serviceProviders) {
		this.name = serviceProviders.getName();
		this.address = serviceProviders.getAddress();
		if(serviceProviders.getOwnerId()!=null) {
			this.ownerId = serviceProviders.getOwnerId();
		}
	}
}
