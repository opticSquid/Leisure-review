package com.cts.interim_project.Service_Providers.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.cts.interim_project.Service_Providers.entities.ServiceProviders;
@Repository
public interface ServiceProvidersRepo extends JpaRepository<ServiceProviders, String> {

}
