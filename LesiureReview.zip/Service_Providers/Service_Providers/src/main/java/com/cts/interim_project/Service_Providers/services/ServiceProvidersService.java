package com.cts.interim_project.Service_Providers.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cts.interim_project.Service_Providers.entities.ServiceProviders;
import com.cts.interim_project.Service_Providers.pojo.ServiceProvidersPOJO;
import com.cts.interim_project.Service_Providers.repository.ServiceProvidersRepo;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class ServiceProvidersService {
	@Autowired
	private ServiceProvidersRepo serviceProvidersRepo;

	public String addNewServiceProvider(ServiceProvidersPOJO serviceProvider) {
		ServiceProviders newServiceProvider = new ServiceProviders(serviceProvider);
		ServiceProviders saved = serviceProvidersRepo.save(newServiceProvider);
		log.debug("Saved service Provider = {}", saved);
		return saved.getId();
	}
}
