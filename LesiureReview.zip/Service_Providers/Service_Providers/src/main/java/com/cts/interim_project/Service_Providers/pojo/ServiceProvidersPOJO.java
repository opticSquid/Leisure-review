package com.cts.interim_project.Service_Providers.pojo;

import lombok.Data;
import lombok.ToString;

@Data
@ToString
public class ServiceProvidersPOJO {
	private String name;
	private String address;
	private String ownerId;
}
