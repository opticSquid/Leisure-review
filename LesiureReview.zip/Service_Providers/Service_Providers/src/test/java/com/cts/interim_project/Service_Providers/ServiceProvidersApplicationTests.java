package com.cts.interim_project.Service_Providers;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ServiceProvidersApplicationTests {

	@Test
	void contextLoads() {
	}

}
