package com.cts.interim_project.Reviews.and.Streaks;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ReviewsAndStreaksApplicationTests {

	@Test
	void contextLoads() {
	}

}
